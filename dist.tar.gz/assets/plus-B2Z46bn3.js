import{c as e,n as s,I as o}from"./index-CH3z4mz5.js";var r=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],p=a=>e(o,s(a,{name:"Plus",iconNode:r})),l=p;export{l as p};
