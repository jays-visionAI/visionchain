import{c as r,n as a,I as o}from"./index-CH3z4mz5.js";var t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],h=e=>r(o,a(e,{name:"ChevronRight",iconNode:t})),m=h;export{m as c};
